const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000; // Port sur lequel le serveur écoutera

app.use(express.json());

function saveUserData(name, city, interets) {
    const userData = {
        name: name,
        city: city,
        interets: interets
    };

    fs.readFile('users.json', 'utf8', (err, data) => {
        if (err) {
            console.error("Erreur lors de la lecture du fichier users.json :", err);
            return;
        }

        let jsonData = JSON.parse(data);
        jsonData.users.push(userData);

        fs.writeFile('users.json', JSON.stringify(jsonData, null, 2), 'utf8', (err) => {
            if (err) {
                console.error("Erreur lors de l'écriture dans le fichier users.json :", err);
                return;
            }
            console.log("Données utilisateur enregistrées avec succès dans users.json !");
        });
    });
}

// Endpoint pour servir interface-dentree.html
app.use(express.static(path.join(__dirname, 'public'))); 
// Définir le dossier public pour servir des fichiers statiques

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'interface-dentree.html')); 
    // Envoyer le fichier HTML pour la page d'entrée
});

// Endpoint pour sauvegarder les données utilisateur
app.post('/saveData', (req, res) => {
    const { name, city, interets } = req.body;
    saveUserData(name, city, interets);
    res.status(200).send('Données enregistrées avec succès !');
});

// Démarrer le serveur
app.listen(PORT, () => {
    console.log(`Serveur démarré sur le port ${PORT}`);
});
